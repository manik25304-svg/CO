import re
import sys
if len(sys.argv)<3:
    print("Not of expected type")              
    sys.exit(1)

inset=sys.argv[1]                       
outset=sys.argv[2]  

def j_jumper(pc,label,labelname):
    a=label[labelname]
    pc=a
    return pc
def utype(x):
    arr=[]
    if (x=="lui"):             
        arr.append("0110111")
    elif (x=="auipc"):             
        arr.append("0010111")
    return arr
def rval(a):
    rd=format(a,'05b')
    return str(rd)
def btype(x):
    arr=[]
    if(x=="beq"):
        arr.append("000")              
        arr.append("1100011")
    elif (x=="bne"):
        arr.append("001")              
        arr.append("1100011")
    elif (x=="blt"):
        arr.append("100")              
        arr.append("1100011")
    elif (x=="bge"):
        arr.append("101")              
        arr.append("1100011")
    elif (x=="bltu"):
        arr.append("110")              
        arr.append("1100011")
    elif (x=="bgeu"):
        arr.append("111")              
        arr.append("1100011")
    return arr
def rtype(x):
    arr=[]
    if(x=="sltu"):
        arr.append("0000000")
        arr.append("011")              # type of arr-> func7 , func3 , opcode
        arr.append("0110011")
    elif (x=="xor"):
        arr.append("0000000")
        arr.append("100")              
        arr.append("0110011")
    elif (x=="add"):
        arr.append("0000000")
        arr.append("000")              
        arr.append("0110011")
    elif (x=="sub"):
        arr.append("0100000")
        arr.append("000")              
        arr.append("0110011")
    elif (x=="sll"):
        arr.append("0000000")
        arr.append("001")              
        arr.append("0110011")
    elif (x=="slt"):
        arr.append("0000000")
        arr.append("010")              
        arr.append("0110011")
    elif (x=="or"):
        arr.append("0000000")
        arr.append("110")              
        arr.append("0110011")
    elif (x=="srl"):
        arr.append("0000000")
        arr.append("101")              
        arr.append("0110011")
    elif (x=="and"):
        arr.append("0000000")
        arr.append("111")              
        arr.append("0110011")
    return arr

#def itype(x):

reg= {
    "x0":0, "zero":0,
    "x1":1, "ra":1,
    "x2":2, "sp":2,
    "x3":3, "gp":3,
    "x4":4, "tp":4,
    "x5":5, "t0":5,
    "x6":6, "t1":6,
    "x7":7, "t2":7,
    "x8":8, "s0":8, "fp":8,
    "x9":9, "s1":9,
    "x10":10, "a0":10,          # acesss register based on given value
    "x11":11, "a1":11,
    "x12":12, "a2":12,
    "x13":13, "a3":13,
    "x14":14, "a4":14,
    "x15":15, "a5":15,
    "x16":16, "a6":16,
    "x17":17, "a7":17,
    "x18":18, "s2":18,
    "x19":19, "s3":19,
    "x20":20, "s4":20,
    "x21":21, "s5":21,
    "x22":22, "s6":22,
    "x23":23, "s7":23,
    "x24":24, "s8":24,
    "x25":25, "s9":25,
    "x26":26, "s10":26,
    "x27":27, "s11":27,
    "x28":28, "t3":28,
    "x29":29, "t4":29,
    "x30":30, "t5":30,
    "x31":31, "t6":31,
}
r=["add","sub","sll","slt","sltu","xor","and","or","srl"]
ity=["lw","addi","sltiu","jalr"]
s=["sw"]
b=["beq","bne","blt","bge","bltu","bgeu"]
u=["lui","auipc"]
jtyp=["jal"]
def regchecker(rs,reg):
    if rs in reg:
        return(1)
    else:
        return(0)
def virtual_halt(inst2,pos):
    x=inst2[pos:]
    if len(x)<4:
        return False
    if x[0]!="beq":
        return False
    rs1_checker=x[1] in ("zero","x0")
    rs2_checker=x[2] in ("zero","x0")
    try:
        immval=int(x[3],0)
    except ValueError:
        immval=None
    return rs1_checker and rs2_checker

try:
    with open(inset, 'r') as f:
        instructions = f.readlines()
        pc_place= 0x0000
        label={}
        address_inst={}
        
        for i in instructions:
            inst=re.split(r'[,()\s]+',i)
            inst = [x for x in inst if x]
            if not inst:
                continue
            
            address_inst[hex(pc_place)]=inst
            pc_place+=4
        pc_place=0x0000
        for j in address_inst.values():
            
            inst2=j
            if inst2[0][-1]==":":
                label[inst2[0][:-1]]=pc_place  
            pc_place+=4
        all_keys=list(address_inst.keys())
        if all_keys:
            last_key=all_keys[-1]
            last_val=address_inst[last_key]
            
            lpos=1 if last_val[0][-1]==":" else 0
            if not virtual_halt(last_val,lpos):
                print(f"Missing virtual halt")
                #sys.exit(1)
        wset=[]
        error=[]
        n=0
        for x in address_inst:
            n=n+1
            
            inst2=address_inst[x]
            pos=0
            if inst2[0][-1].endswith(":"):
                pos=1
                if pos>=len(inst2):
                    continue
            line=None
            if(inst2[pos] in r):
                if len(inst2[pos:])==4:
                    if regchecker(inst2[pos+3],reg)==0 or regchecker(inst2[pos+2],reg)==0 or regchecker(inst2[pos+1],reg)==0:
                        line=("Invalid Register name")
                        with open(sys.argv[2], 'w') as f:
                            f.write(line + " ")
                            f.write(str(n)+ "\n")
                        sys.exit(1)
                    else:
                        a=rtype(inst2[pos])
                        rs2=rval(reg[inst2[pos+3]])
                        rs1=rval(reg[inst2[pos+2]])
                        rd=rval(reg[inst2[pos+1]])
                        line=(a[0]+rs2+rs1+a[1]+rd+a[2])
                else:
                    line=("Invalid number of Arguments in the instruction")
                    with open(sys.argv[2], 'w') as f:
                        f.write(line + " ")
                        f.write(str(n)+ "\n")
                        
                    sys.exit(1)
            elif(inst2[pos] in ity):
                if len(inst2[pos:])==4:
                    if(inst2[pos]=="lw"):
                        rs1=inst2[pos+3]
                        rd=inst2[pos+1]
                        if regchecker(rd,reg)==0 or regchecker(rs1,reg)==0:
                            line=("Invalid Register name")
                            with open(sys.argv[2], 'w') as f:
                                f.write(line + " ")
                                f.write(str(n)+ "\n")
                            sys.exit(1)
                        else:
                            rs1=rval(reg[rs1])
                            rd=rval(reg[rd])

                            imm = int(inst2[pos+2],0)
                            imm = format(imm & 0xfff, '012b')
                            imm=str(imm)
                            opcode="0000011"
                            func3="010"
                            line=(imm+rs1+func3+rd+opcode)
                    elif(inst2[pos]=="addi" or inst2[pos]=="sltiu" or inst2[pos]=="jalr"):
                        if regchecker(inst2[pos+2],reg)==0 or regchecker(inst2[pos+1],reg)==0:
                            line=("Invalid Register name")
                            with open(sys.argv[2], 'w') as f:
                                f.write(line + " ")
                                f.write(str(n)+ "\n")
                            sys.exit(1)
                        else:    
                            imm = int(inst2[pos+3],0)
                            imm = format(imm & 0xfff, '012b')
                            imm=str(imm)
                            rs1=rval(reg[inst2[pos+2]])
                            rd=rval(reg[inst2[pos+1]])
                            if(inst2[pos]=="addi"):
                                opcode="0010011"
                                func3="000"
                                line=(imm+rs1+func3+rd+opcode)
                            elif(inst2[pos]=="sltiu"):
                                opcode="0010011"
                                func3="011"
                                line=(imm+rs1+func3+rd+opcode)
                            elif(inst2[pos]=="jalr"):
                                opcode="1100111"
                                func3="000"
                                line=(imm+rs1+func3+rd+opcode)
                else:
                    line=("Invalid number of Arguments in the instruction")
                    with open(sys.argv[2], 'w') as f:
                        f.write(line + " ")
                        f.write(str(n)+ "\n")
                    sys.exit(1)
            elif(inst2[pos+0] in s):
                if len(inst2[pos:])==4:
                    if(inst2[pos+0]=="sw"):
                        if regchecker(inst2[pos+1],reg)==0 or regchecker(inst2[pos+3],reg)==0:
                            line=("Invalid Register Name")
                            with open(sys.argv[2], 'w') as f:
                                f.write(line + " ")
                                f.write(str(n)+ "\n")
                            sys.exit(1)
                        else:
                            imm=int(inst2[pos+2],0)
                            imm = format(imm & 0xfff, '012b')
                            imm=str(imm)
                            rs2=rval(reg[inst2[pos+1]])
                            rs1=rval(reg[inst2[pos+3]])
                            func3="010"
                            opcode="0100011"
                            line=(imm[0:7]+rs2+rs1+func3+imm[7:12]+opcode)
                        
                else:
                    line=("Invalid number of arguments in the instruction")
                    with open(sys.argv[2], 'w') as f:
                        f.write(line + " ")
                        f.write(str(n)+ "\n")
                    sys.exit(1)
            elif(inst2[pos+0] in u):
                if len(inst2[pos:])==3:
                    if regchecker(inst2[pos+1],reg)==0:
                        line=("Invalid Register name")
                        with open(sys.argv[2], 'w') as f:
                            f.write(line + " ")
                            f.write(str(n)+ "\n")
                        sys.exit(1)
                    else:
                        a=utype(inst2[pos+0])
                        rd=rval(reg[inst2[pos+1]])
                        imm=int(inst2[pos+2],0)
                        
                        imm = format(imm & 0xfffff , '020b')
                        imm=str(imm)
                        line=(imm+rd+a[0])
                else:
                    line=("Invalid number of arguments in the instruction")
                    with open(sys.argv[2], 'w') as f:
                        f.write(line + " ")
                        f.write(str(n)+ "\n")
                    sys.exit(1)
            elif(inst2[pos] in b):
                if len(inst2[pos:])==4:
                    if regchecker(inst2[pos+1],reg)==0 or regchecker(inst2[pos+2],reg)==0:
                        line=("Invalid Register name")
                        with open(sys.argv[2], 'w') as f:
                            f.write(line + " ")
                            f.write(str(n)+ "\n")
                        sys.exit(1)
                    else:
                        a=btype(inst2[pos])
                        rs1=rval(reg[inst2[pos+1]])
                        rs2=rval(reg[inst2[pos+2]])
                        imm=inst2[pos+3]
                        pc=int(x,16)
                        if imm.lstrip('-').isdigit():
                            imm=int(imm,0)
                        
                        else:
                            if imm not in label:
                                line=(f"Undefined label '{imm}'")
                                with open(sys.argv[2], 'w') as f:
                                    f.write(line + " ")
                                    f.write(str(n)+ "\n")
                                sys.exit(1)
                            imm=label[imm]-pc  
                        imm = format(imm & 0x1fff , '013b')
                        line=(imm[0]+imm[2:8]+rs2+rs1+a[0]+imm[8:12]+imm[1]+a[1])
                else:
                    line=("Invalid number of arguments in the instuction")
                    with open(sys.argv[2], 'w') as f:
                        f.write(line + " ")
                        f.write(str(n)+ "\n")
                    sys.exit(1)
            elif(inst2[pos] in jtyp):
                if len(inst2[pos:])==3:
                    if inst2[pos] == "jal":
                        if regchecker(inst2[pos+1],reg)==0:
                            line=("Invalid Register name")
                            with open(sys.argv[2], 'w') as f:
                                f.write(line + " ")
                                f.write(str(n)+ "\n")
                            sys.exit(1)
                        else:
                            opcode="1101111"
                            rd=rval(reg[inst2[pos+1]])
                            imm = inst2[pos+2]
                            pc = int(x, 16)
                            if imm.lstrip('-').isdigit():
                                imm=int(imm,0)
                            
                            else:
                                if imm not in label:
                                    line = "Invalid Label"
                                    with open(sys.argv[2], 'w') as f:
                                        f.write(line + " " + str(n) + "\n")
                                    sys.exit(1)
                                else:
                                    imm = label[imm] - pc 
                            imm = format(imm & 0x1fffff, '021b')
                            line=(imm[0]+imm[10:20]+imm[9]+imm[1:9]+rd+opcode)
                else:
                    line=("Invalid number of arguments in the instruction")
                    with open(sys.argv[2], 'w') as f:
                        f.write(line + " ")
                        f.write(str(n)+ "\n")
                    sys.exit(1)
            
            else:
                line= ("Command not found")
                with open(sys.argv[2], 'w') as f:
                    f.write(line + " ")
                    f.write(str(n)+ "\n")
                sys.exit(1)
            if(line!=None): wset.append(line)

        with open(sys.argv[2], 'w') as f:
            for line in wset:
               f.write(line + "\n")
            
except FileNotFoundError:
    print(f"Error: The file '{inset}' was not found.")
    sys.exit(1)
except Exception as e:
    print(f"An error occurred: {e}")
    sys.exit(1)
